import { BookingDetails } from './../bookingDetails';
import { BusClass } from './../BusClass';
import { BookingClass } from './../BookingClass';
import { AdminDataService } from './../admin-data.service';
import { FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';

import { Component, OnInit } from '@angular/core';
import { catchError } from 'rxjs/operators';
import { HttpErrorResponse } from '@angular/common/http';
import { throwError } from 'rxjs';


@Component({
  selector: 'app-generate-report',
  templateUrl: './generate-report.component.html',
  styleUrls: ['./generate-report.component.css']
})
export class GenerateReportComponent implements OnInit
 {
  bookingdetailsflag = false;
  bookingflag = false;
  bus : BusClass[];
  booking : BookingClass[];
  bookingdetails : BookingDetails[] = [];
  busObj : BusClass;
 viewReport = new FormGroup({
   busId : new FormControl('')
 })

  constructor(private adminService : AdminDataService) { }

  ngOnInit(): void 
  {
    this.adminService.getBus().subscribe((bus)=>
    {
      this.bus = bus;
    });
    document.getElementById('bookingTable').style.display="none";
  }


  viewReports()
  { 
        let busId = this.viewReport.get('busId').value;
//     this.adminService.getBookingById(busId).subscribe((booking)=>
//     {
//       this.booking = booking;
//       console.log(this.booking);
//     })
   
//     this.bookingflag = true;

//   this.bookingdetailsflag = true;
  
//   for(let i=0;i<this.bus.length;i++)
//   {
//     if(this.bus[i].busId==busId)
//     {
//       this.busObj = this.bus[i];
//       break;
//     }
//   }
//   console.log("yes")

//   let bookingdetailobj= new BookingDetails(this.booking.busId, this.booking.passengerNames,this.booking.seatsBooked, this.booking.totalFare, this.booking.bookingId, this.booking.seatNo, this.busObj.sourceStation, this.busObj.destinationStation, this.busObj.boardingTime, this.busObj.dropTime, this.busObj.busType);
//   this.bookingdetails.push(bookingdetailobj);

//  console.log(this.bookingdetails);
 
//  document.getElementById("bookingTable").style.display="block";


    this.booking=[];
    this.adminService.getBookingById(busId).subscribe(data=>this.booking=data);
    for(let i=0;i<this.bus.length;i++)
  {
    if(this.bus[i].busId==busId)
    {
      console.log("true");
      this.busObj = this.bus[i];
      break;
    }
  }
  console.log("yes")
  // for(let i=0;i<this.booking.length;i++)
  // {   console.log("tttttttttt")
  // let bookingdetailobj= new BookingDetails(this.booking[i].busId, this.booking[i].passengerNames,this.booking[i].seatsBooked, this.booking[i].totalFare, this.booking[i].bookingId, this.booking[i].seatNo, this.busObj.sourceStation, this.busObj.destinationStation, this.busObj.boardingTime, this.busObj.dropTime, this.busObj.busType);
  // this.bookingdetails.push(bookingdetailobj);
  // }
    document.getElementById("bookingTable").style.display="block";
  }

  }  

 


