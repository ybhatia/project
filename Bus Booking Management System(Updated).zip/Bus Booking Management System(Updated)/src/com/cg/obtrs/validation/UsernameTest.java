package com.cg.obtrs.validation;

import static org.junit.Assert.*;

import org.junit.Test;

public class UsernameTest {
	Validation validation = new Validation();
	@Test
	public void testUserName() {
	  boolean isUserNameValid = validation.isValidUserName("amaan60");
	  assertTrue(isUserNameValid); 
	}
}
