package com.cg.obtrs.dao;
import java.time.LocalDateTime;
import java.util.ArrayList;
import com.cg.obtrs.dto.AdminDTO;
import com.cg.obtrs.dto.BookingDTO;
import com.cg.obtrs.exception.CustomException;

public interface AdminDAO {

 

     public String adminSignUp(AdminDTO adminDto) throws CustomException;
        
     public String adminLogIn(String userName, String password) throws CustomException;
     
     public String addBusOrRoute(int busId, String sourceStation, String destinationStation,LocalDateTime boardingTime, LocalDateTime dropTime, String busType, Integer totalSeats,
                Float fare) throws CustomException;
     
     public ArrayList<BookingDTO> generateReport() throws CustomException;
     
     public String cancelBooking(int busId, int bookingId) throws CustomException;
     
     public String updateSourceStation(int busId,String sourceStation) throws CustomException;
     
     public String updateDestinationStation(int busId,String destinationStation) throws CustomException;
     
     public String updateBoardingTime(int busId,LocalDateTime boardingTime) throws CustomException;
     
     public String updateDropTime(int busId,LocalDateTime dropTime) throws CustomException;
     
     public String updateBustype(int busId,String busType) throws CustomException;
     
     public String updateTotalSeats(int busId,int totalSeats) throws CustomException;
     
     public String updateFare(int busId,Float fare) throws CustomException;
     
     
     
}