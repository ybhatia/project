import { Booking } from './../Booking';
import { BusClass } from './../BusClass';
import { AdminDataService } from './../admin-data.service';
import { Component, OnInit } from '@angular/core';
import { BusService } from 'src/app/bus.service';
import { Router } from '@angular/router';
import { FormGroup, FormControl } from '@angular/forms';
import { Bus } from 'src/app/Bus';
import { ifStmt } from '@angular/compiler/src/output/output_ast';

@Component({
  selector: 'app-update-source-station',
  templateUrl: './update-source-station.component.html',
  styleUrls: ['./update-source-station.component.css']
})

export class UpdateSourceStationComponent implements OnInit {
  flag1:boolean;
  tempBus:Bus[];
  bus: BusClass[];

   
  constructor(private adminSer:AdminDataService,private router:Router) { }
   
  updateSourcestation = new FormGroup ({
    busId : new FormControl(''),
    sourceStation : new FormControl('')

  })
 

  ngOnInit(): void {
      this.adminSer.getBus().subscribe(data=>this.bus=data);
   
  }
  
  updateSourceStation(){
    let busId=this.updateSourcestation.get('busId').value;
    let sourceStation=this.updateSourcestation.get('sourceStation').value;
    for(let i=0;i<this.bus.length;i++)
    { 
      if(this.bus[i].busId==busId)
      {
        this.adminSer.updateBusBySourceStation(busId,sourceStation).subscribe(data => console.log(data));
        this.flag1=true;
      }
  
   
      
     
      // }
      // else      
      // window.alert("Entered Station is same as old one. Please enter a new Station.");
     }
    }
    
  }



