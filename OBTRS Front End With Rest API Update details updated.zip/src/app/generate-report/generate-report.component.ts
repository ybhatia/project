import { BookingDetails } from './../bookingDetails';
import { BusClass } from './../BusClass';
import { BookingClass } from './../BookingClass';
import { AdminDataService } from './../admin-data.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';

import { Component, OnInit } from '@angular/core';
import { catchError } from 'rxjs/operators';
import { HttpErrorResponse } from '@angular/common/http';
import { throwError } from 'rxjs';


@Component({
  selector: 'app-generate-report',
  templateUrl: './generate-report.component.html',
  styleUrls: ['./generate-report.component.css']
})
export class GenerateReportComponent implements OnInit
 {
  bookingdetailsflag = false;
  bookingflag = false;
  bus : BusClass[];
  booking : BookingClass[];
  bookingdetails : BookingDetails[] = [];
  busObj : BusClass;
 viewReport = new FormGroup({
   busId : new FormControl('', Validators.required)
 })

  constructor(private adminService : AdminDataService , private router :Router) { }

  ngOnInit(): void 
  {
    this.adminService.getBus().subscribe((bus)=>
    {
      this.bus = bus;
    });
    document.getElementById('bookingTable').style.display="none";
  }


  viewReports()
  { 
        let busId = this.viewReport.get('busId').value;
    this.booking=[];
    this.adminService.getBookingById(busId).pipe(catchError((error:HttpErrorResponse)=>{
      this.router.navigate(["show-error",error.error.message]);
      return throwError(error.error.message)})).subscribe(data=>this.booking=data);
    for(let i=0;i<this.bus.length;i++)
  {
    if(this.bus[i].busId==busId)
    {
      console.log("true");
      this.busObj = this.bus[i];
      break;
    }
  }
    document.getElementById("bookingTable").style.display="block";
  }

  }  

 


