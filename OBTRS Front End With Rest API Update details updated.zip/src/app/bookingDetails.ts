export class BookingDetails
{
    busId : number;
    passengerNames: string;
    seatsBooked : number; 
    totalFare : string;
    bookingId : number;
    seatNo : string;
    sourceStation : string;
    destinationStation : string;
    boardingTime : string;
    dropTime : string;
    busType : string;

    constructor(busId, passengerNames, seatsBooked, totalFare, bookingId, seatNo, sourceStation, destinationStation, boardingTime, dropTime, busType)
    {
        this.busId = busId;
        this.passengerNames = passengerNames;
        this.seatsBooked = seatsBooked;
        this.totalFare = totalFare;
        this.bookingId = bookingId;
        this.seatNo = seatNo;
        this.sourceStation = sourceStation;
        this.destinationStation= destinationStation;
        this.boardingTime = boardingTime;
        this.dropTime = dropTime;
        this.busType = busType;
    }
}