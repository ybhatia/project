import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddBusOrRouteComponent } from './add-bus-or-route.component';

describe('AddBusOrRouteComponent', () => {
  let component: AddBusOrRouteComponent;
  let fixture: ComponentFixture<AddBusOrRouteComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddBusOrRouteComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddBusOrRouteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
