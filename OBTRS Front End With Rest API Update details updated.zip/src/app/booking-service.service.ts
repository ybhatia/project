import { BookingClass } from './BookingClass';
import { BookingService } from 'src/app/booking.service';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Booking } from './Booking';
import { map} from 'rxjs/operators';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class BookingServiceService {
  
  constructor(private http:HttpClient) { }
  httpOptions={
    headers:new HttpHeaders({
      'Content-Type':'application/json'
    })
}
  getBooking():Observable<BookingClass[]>
  {
   return this.http.get<BookingClass[]>("http://localhost:8080/api/booking", this.httpOptions);
  }
  addBooking(booking:BookingClass)
  {
    return this.http.post('http://localhost:8080/api/booking',booking);
  }
  getBookingById(id: number)
  {
    return this.http.get("http://localhost:8080/api/booking/"+id);
  }

  deleteBooking(id:any)
  {
    console.log("yup......");
    return this.http.delete("http://localhost:8080/api/delete/"+id);
  }
 
  updateBooking(id:any,booking:BookingClass)
  {
    return this.http.put('http://localhost:8080/api/booking/'+id,booking);
  }
    
}

