import { BookingClass } from './BookingClass';
import { BusbookingComponent } from './busbooking/busbooking.component';
import { Observable } from 'rxjs';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BusClass } from './BusClass';

@Injectable({
  providedIn: 'root'
})
export class AdminDataService {
  private options = { headers: new HttpHeaders().set('Content-Type', 'application/json') };
  constructor(private httpClient:HttpClient) { }

  login(email:string,password:string):Observable<boolean>{
    return this.httpClient.get<boolean>("http://localhost:8080/api/login/"+email+'/'+password, this.options);
  }


  getBus():Observable<BusClass[]>
  {
   return this.httpClient.get<BusClass[]>("http://localhost:8080/api/bus",this.options);
  }

  addBus(bus:BusClass) : Observable<BusClass>
  {
   return this.httpClient.post<BusClass>("http://localhost:8080/api/addBus", JSON.stringify(bus), this.options );
  }
 
  
  deleteBus(id:any): Observable<BusClass>
  {
    return this.httpClient.delete<BusClass>("http://localhost:8080/api/delete"+id, this.options);
  }
 
  updateBus(id:any,Bus:BusClass)
  {
    return this.httpClient.put('http://localhost:8080/api/bus'+id,Bus);
  }

  getBooking(): Observable<BookingClass>
  {
   return this.httpClient.get<BookingClass>("http://localhost:8080/api/booking", this.options);
  }
  addBooking(booking:BookingClass)
  {
    return this.httpClient.post('http://localhost:8080/api/booking',booking);
  }
  getBookingById(id: any): Observable<BookingClass[]>
  {
    return this.httpClient.get<BookingClass[]>("http://localhost:8080/api/booking/bus/"+id, this.options);
  }

  deleteBooking(id:any):Observable<number[]>
  {
    return this.httpClient.delete<number[]>("http://localhost:8080/api/delete/"+id, this.options);
  }
 
  updateBooking(id:any,booking:BookingClass)
  {
    return this.httpClient.put('http://localhost:8080/api/booking/'+id,booking);
  }
}
