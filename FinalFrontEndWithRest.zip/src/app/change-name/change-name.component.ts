import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';
import { Router } from '@angular/router';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-change-name',
  templateUrl: './change-name.component.html',
  styleUrls: ['./change-name.component.css']
})
export class ChangeNameComponent implements OnInit {
  flag1:boolean;
  tempCustomer:any;
  constructor(private custSer:CustomerService,private router:Router) { }
  changename = new FormGroup({
    customerEmail: new FormControl(''),
    password: new FormControl(''),
    name: new FormControl('')
  })
    ngOnInit(): void 
    {
      this.custSer.getCustomer();
    }
  changeName()
  {
  let customerEmail = this.changename.get('customerEmail').value;
  let password=this.changename.get('password').value;
  let name=this.changename.get('name').value;
    for(let i=0;i<this.custSer.customerDb.length;i++) 
    {
      if ((this.custSer.customerDb[i].customerEmail == customerEmail)&&(this.custSer.customerDb[i].customerPassword==password))
      {
            this.custSer.customerDb[i].customerName=name;
            this.tempCustomer=this.custSer.customerDb[i];
            this.custSer.updateCustomer(this.custSer.customerDb[i].id,this.tempCustomer).subscribe(data=>{console.log(data)});
            this.custSer.flag=true; 
      }     
    }
    if (this.custSer.flag) 
    {
      this.flag1=true;
      this.router.navigateByUrl("/edit-profile");
    }
  }
}
