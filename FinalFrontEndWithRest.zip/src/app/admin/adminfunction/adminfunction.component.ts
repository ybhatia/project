import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminfunction',
  templateUrl: './adminfunction.component.html',
  styleUrls: ['./adminfunction.component.css']
})
export class AdminfunctionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
