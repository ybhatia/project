export class Booking
{
    id:any;
    busId:any;
    passengerNames:any[];
    seatBooked:any;
    passengerEmail:any;
    totalFare:any;
    feedBack:any;
    rating:any;
    
    constructor(id,busId,passengerNames,seatBooked,passengerEmail,totalFare,feedBack,rating)
    {
        this.id=id;
        this.busId=busId;
        this.passengerNames=passengerNames;
        this.seatBooked=seatBooked;
        this.passengerEmail=passengerEmail;
        this.totalFare=totalFare;
        this.feedBack=feedBack;
        this.rating=rating;
    }
}