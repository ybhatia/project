package com.cg.web.obtrs.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.web.obtrs.entities.BookingEntity;
import com.cg.web.obtrs.entities.BusEntity;
import com.cg.web.obtrs.service.AdminService;
import com.cg.web.obtrs.service.AdminServiceImpl;

@RestController
@RequestMapping("/api")
@CrossOrigin("*")
public class BusController {
	
	@Autowired
	private AdminService adminService;
	
	@GetMapping("/login/{email}/{password}")
	public boolean login(@PathVariable String email, @PathVariable String password)
	{
		return adminService.login(email,password);
	}
	
	@GetMapping("/bus")
	public List<BusEntity> getAllBus()
	{
		return adminService.getAllBus();
	}
	
	@CrossOrigin("*")
	@PostMapping("/addBus")
	public BusEntity addBusOrRoute(@RequestBody BusEntity bus) {
		return adminService.addBusOrRoute(bus);
		
	}
	@GetMapping("/bus/{busId}")
	public Optional<BusEntity> getBus(@PathVariable Integer busId)
	{
		return adminService.getBus(busId);
	}
	
	@GetMapping("/booking")
	public List<BookingEntity> getAllBooking()
	{
		return adminService.getAllBooking();
	}
	@CrossOrigin("*")
	@GetMapping("/booking/{bookingId}")
	public Optional<BookingEntity> getBooking(@PathVariable Integer bookingId)
	{
		return adminService.getBooking(bookingId);
	}
	@CrossOrigin("*")
	@GetMapping("/booking/bus/{busId}")
	public List<BookingEntity> getBookingbyBusId(@PathVariable Integer busId)
	{	
		return adminService.getBookingbyBusId(busId);
	}
	
	
	@DeleteMapping("/delete/{bookingId}")
	public List<Integer> cancelBooking(@PathVariable Integer bookingId)
	{
		return adminService.cancelBooking(bookingId);
		
		
	}
	
	@PutMapping("/update/sourceStation/{busId}/{sourceStation}")
	public List<BusEntity> updateBusBySourceStation(@PathVariable Integer busId , @PathVariable String sourceStation)
	{
		return adminService.updateBusBySourceStation(busId,sourceStation);
	}
	
	@PutMapping("/update/destinationStation/{busId}/{destinationStation}")
	public List<BusEntity> updateBusByDestinationStation(@PathVariable Integer busId , @PathVariable String destinationStation)
	{
		return adminService.updateBusByDestinationStation(busId,destinationStation);
	}
	
	@PutMapping("/update/boardingTime/{busId}/{boardingTime}")
	public List<BusEntity> updateBusByBoardingTime(@PathVariable Integer busId , @PathVariable String boardingTime)
	{
		return adminService.updateBusByBoardingTime(busId,boardingTime);
	}
	
	@PutMapping("/update/dropTime/{busId}/{dropTime}")
	public List<BusEntity> updateBusByDropTime(@PathVariable Integer busId , @PathVariable String dropTime)
	{
		return adminService.updateBusByDropTime(busId,dropTime);
	}
	
	@PutMapping("/update/busType/{busId}/{busType}")
	public List<BusEntity> updateBusByBusType(@PathVariable Integer busId , @PathVariable String busType)
	{
		return adminService.updateBusByBusType(busId,busType);
	}
	
	@PutMapping("/update/totalSeats/{busId}/{totalSeats}")
	public List<BusEntity> updateBusByTotalSeats(@PathVariable Integer busId , @PathVariable int totalSeats)
	{
		return adminService.updateBusByTotalSeats(busId,totalSeats);
	}
	
	@PutMapping("/update/fare/{busId}/{fare}")
	public List<BusEntity> updateBusByFare(@PathVariable Integer busId , @PathVariable float fare)
	{
		return adminService.updateBusByFare(busId,fare);
	}
	
}
