package com.cg.web.obtrs.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cg.web.obtrs.dao.BookingDao;
import com.cg.web.obtrs.dao.BusDao;
import com.cg.web.obtrs.entities.BookingEntity;
import com.cg.web.obtrs.entities.BusEntity;

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	private BookingDao bookingDao;
	
	@Autowired 
	private BusDao busDao;
	
	@Override
	public List<BusEntity> getAllBus() {
		
		return busDao.findAll();
	}

	@Override
	public BusEntity addBusOrRoute(BusEntity bus) {
		
		return busDao.save(bus);
	}

	@Override
	public Optional<BusEntity> getBus(Integer busId) {
	
		return busDao.findById(busId);
	}

	@Override
	public List<BookingEntity> getAllBooking() {
		
		return bookingDao.findAll();
	}

	@Override
	public Optional<BookingEntity> getBooking(Integer bookingId) {
		
		return bookingDao.findById(bookingId);
	}

	@Override
	public List<BookingEntity> getBookingbyBusId(Integer busId) {
		List<BookingEntity> allBookingsList = (List<BookingEntity>) bookingDao.findAll();
		List<BookingEntity> bookingsByBusId = new ArrayList<BookingEntity>();
		for(int i=0;i<allBookingsList.size();i++)
		{
			if(allBookingsList.get(i).getBusId()==busId)
			{
				bookingsByBusId.add(allBookingsList.get(i));
			}
		}
//		if(bookingsByBusId.isEmpty())
//		{
//			throw new DataNotFoundException("Error while fetching data: NO BOOKINGS FOUND FOR GIVEN HOTEL!..");
//		}
		return bookingsByBusId;
	}

	@Override
	public List<Integer> cancelBooking(Integer bookingId) {
		
		List<BookingEntity>allBookings = (List<BookingEntity>)bookingDao.findAll();
		List<Integer> bookingIds = new ArrayList<Integer>();
		for(int i=0;i<allBookings.size();i++)
		{
			if(allBookings.get(i).getBookingId()==bookingId)
			{
				bookingIds.add(allBookings.get(i).getBookingId());
				bookingDao.deleteById(allBookings.get(i).getBookingId());
			}
		}
		return bookingIds;
	}

	@Override
	public BusEntity updateBus(BusEntity bus) {
		
		return busDao.save(bus);
	}

}
