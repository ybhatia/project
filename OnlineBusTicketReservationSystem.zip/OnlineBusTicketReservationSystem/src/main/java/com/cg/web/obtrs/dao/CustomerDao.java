package com.cg.web.obtrs.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.cg.web.obtrs.entities.CustomerEntity;

@CrossOrigin("*")
public interface CustomerDao extends JpaRepository<CustomerEntity, Integer> {
 
}
