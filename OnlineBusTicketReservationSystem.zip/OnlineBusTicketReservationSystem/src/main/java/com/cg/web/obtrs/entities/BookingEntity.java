package com.cg.web.obtrs.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "Booking")
public class BookingEntity 
{
		@Id
		@Column(name = "BOOKING_ID")
	    private int bookingId;
		@Column(name = "BUS_ID")
		private int busId;
	    @ElementCollection
		private List<String> passengerNames = new ArrayList<>();
		@Column(name = "SEATS_BOOKED")
		private Integer seatsBooked;
		@Column(name = "TOTAL_FARE")
		private float totalFare;
		@Column (name = "seat_no")
		private String seatNo;
		public BookingEntity()
		{
			
		}
		
		public BookingEntity(int busId, List<String> passengerNames, Integer seatsBooked, float totalFare, int bookingId, String seatNo) {
			super();
			this.busId = busId;
			this.passengerNames = passengerNames;
			this.seatsBooked = seatsBooked;
			this.totalFare =totalFare;
			this.bookingId = bookingId;
			this.seatNo = seatNo;
		}


		public int getBusId() {
			return busId;
		}

		public void setBusId(int busId) {
			this.busId = busId;
		}

		
		public Integer getSeatsBooked() {
			return seatsBooked;
		}
		
		public void setSeatsBooked(Integer seatsBooked) {
			this.seatsBooked = seatsBooked;
		}
		public List<String> getPassengerNames() {
			return passengerNames;
		}
		public void setPassengerNames(List<String> passengerNames) {
			this.passengerNames = passengerNames;
		}


		public float getTotalFare() {
			return totalFare;
		}


		public void setTotalFare(float totalFare) {
			this.totalFare = totalFare;
		}

	   
		public int getBookingId() {
			return bookingId;
		}

		public void setBookingId(int bookingId) {
			this.bookingId = bookingId;
		}
		

		public String getSeatNo() {
			return seatNo;
		}

		public void setSeatNo(String seatNo) {
			this.seatNo = seatNo;
		}

		@Override
		public String toString() {
			return "BookingEntity [bookingId=" + bookingId + ", busId=" + busId + ", passengerNames=" + passengerNames
					+ ", seatsBooked=" + seatsBooked + ", totalFare=" + totalFare + ", seatNo=" + seatNo + "]";
		}

//		@Override
//		public String toString() {
//			return "BookingDTO [busId=" + busId + ", passengerNames=" + passengerNames + ", seatsBooked=" + seatsBooked
//					+ ", totalFare=" + totalFare + "]";
//		}

		
}
