package com.cg.web.obtrs.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.web.obtrs.entities.BookingEntity;
import com.cg.web.obtrs.entities.BusEntity;
import com.cg.web.obtrs.service.AdminService;
import com.cg.web.obtrs.service.AdminServiceImpl;

@RestController
@RequestMapping("/api")
@CrossOrigin("*")
public class BusController {
	
	@Autowired
	private AdminService adminService;
	
	
	
	@GetMapping("/bus")
	public List<BusEntity> getAllBus()
	{
		return adminService.getAllBus();
	}
	
	@CrossOrigin("*")
	@PostMapping("/addBus")
	public BusEntity addBusOrRoute(@RequestBody BusEntity bus) {
		return adminService.addBusOrRoute(bus);
		
	}
	@GetMapping("/bus/{busId}")
	public Optional<BusEntity> getBus(@PathVariable Integer busId)
	{
		return adminService.getBus(busId);
	}
	
	@GetMapping("/booking")
	public List<BookingEntity> getAllBooking()
	{
		return adminService.getAllBooking();
	}
	@CrossOrigin("*")
	@GetMapping("/booking/{bookingId}")
	public Optional<BookingEntity> getBooking(@PathVariable Integer bookingId)
	{
		return adminService.getBooking(bookingId);
	}
	@CrossOrigin("*")
	@GetMapping("/booking/bus/{busId}")
	public List<BookingEntity> getBookingbyBusId(@PathVariable Integer busId)
	{	
		return adminService.getBookingbyBusId(busId);
	}
	
	
	@DeleteMapping("/delete/{bookingId}")
	public List<Integer> cancelBooking(@PathVariable Integer bookingId)
	{
		return adminService.cancelBooking(bookingId);
		
		
	}
	
	@PutMapping("/update")
	public BusEntity updateBus(@RequestBody BusEntity bus)
	{
		return adminService.updateBus(bus);
	}
	
}
