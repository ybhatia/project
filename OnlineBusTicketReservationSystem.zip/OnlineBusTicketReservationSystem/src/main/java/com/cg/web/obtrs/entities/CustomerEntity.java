package com.cg.web.obtrs.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name = "Customer")
@Table(name = "Customer")
public class CustomerEntity 
{
	@Id
	 @Column(name = "CUST_ID")
	 private Integer custID;
	 @Column(name = "CUST_NAME")
	 private  String custName;
	 @Column(name = "CUST_PHONENUMBER")
	 private  Long custPhoneNumber;
	 @Column(name = "CUST_EMAIL")
	 private String custEmail;
	 @Column(name = "CUST_USERNAME")
	 private String custUserName;
	 @Column(name = "CUST_PASSWORD")
	 private String custPassword;
	 @Column(name = "CUST_FEEDBACK")
	 private String feedBack;
	 @Column(name = "CUST_RATING")
	 private int rating;
	 @Column(name = "CUST_AGE")
	 private int Age;

	 public String getFeedBack() {
		return feedBack;
	}
	public void setFeedBack(String feedBack) {
		this.feedBack = feedBack;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public int getAge() {
		return Age;
	}
	public void setAge(int age) {
		Age = age;
	}
	public String getCustUserName() {
		return custUserName;
	}
	public void setCustUserName(String custUserName) {
		this.custUserName = custUserName;
	}
	public String getCustPassword() {
		return custPassword;
	}
	public void setCustPassword(String custPassword) {
		this.custPassword = custPassword;
	}
	public CustomerEntity(String custName, Long custPhoneNumber, String custEmail, Integer custID, String custUserName, String custPassword) 
	 {
			super();
			this.custName = custName;
			this.custPhoneNumber = custPhoneNumber;
			this.custEmail = custEmail;
			this.custID = custID;
			this.custUserName = custUserName;
			this.custPassword = custPassword;
	 }
	  public CustomerEntity()
	  {
		  
	  }
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public Long getCustPhoneNumber() {
		return custPhoneNumber;
	}
	public void setCustPhoneNumber(Long custPhoneNumber) {
		this.custPhoneNumber = custPhoneNumber;
	}
	public String getCustEmail() {
		return custEmail;
	}
	public void setCustEmail(String custEmail) {
		this.custEmail = custEmail;
	}
	public Integer getCustID() {
		return custID;
	}
	public void setCustID(Integer custID) {
		this.custID = custID;
	}
	@Override
	public String toString() {
		return "[custName=" + custName + ", custPhoneNumber=" + custPhoneNumber + ", custEmail=" + custEmail
				+ ", custID=" + custID + "]";
	}

}
