package com.cg.web.obtrs.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.cg.web.obtrs.entities.BookingEntity;
import com.cg.web.obtrs.entities.BusEntity;

@Service
public interface AdminService {
	 List<BusEntity> getAllBus();
	 BusEntity addBusOrRoute( BusEntity bus);
	 Optional<BusEntity> getBus( Integer busId);
	 List<BookingEntity> getAllBooking();
	 Optional<BookingEntity> getBooking( Integer bookingId);
	 List<BookingEntity> getBookingbyBusId( Integer busId);
	 List<Integer> cancelBooking( Integer bookingId);
	 BusEntity updateBus( BusEntity bus);

}
