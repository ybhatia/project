import { UpdateSeatsComponent } from './update-seats/update-seats.component';
import { UpdateFareComponent } from './update-fare/update-fare.component';
import { UpdateDropTimeComponent } from './update-drop-time/update-drop-time.component';
import { UpdateBusTypeComponent } from './update-bus-type/update-bus-type.component';
import { UpdateDestinationStationComponent } from './update-destination-station/update-destination-station.component';
import { UpdateSourceStationComponent } from './update-source-station/update-source-station.component';
import { UpdateBoardingTimeComponent } from './update-boarding-time/update-boarding-time.component';
import { CancelBookingComponent } from './cancel-booking/cancel-booking.component';
import { UpdateDetailsComponent } from './update-details/update-details.component';
import { GenerateReportComponent } from './generate-report/generate-report.component';
import { AddBusOrRouteComponent } from './add-bus-or-route/add-bus-or-route.component';
import { AdminfunctionComponent } from './admin/adminfunction/adminfunction.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserComponent } from './user/user.component'
import { HomeComponent } from './home/home.component';
import { BusbookingComponent } from './busbooking/busbooking.component';
import { GenerateTicketComponent } from './generate-ticket/generate-ticket.component';
import { CancelTicketComponent } from './cancel-ticket/cancel-ticket.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { ChangeAgeComponent } from './change-age/change-age.component';
import { ChangeNameComponent } from './change-name/change-name.component';
import { ChangePhoneNumberComponent } from './change-phone-number/change-phone-number.component';
import { FeedbackRatingComponent } from './feedback-rating/feedback-rating.component';
import { AppComponent } from './app.component';
import { AdminComponent } from './admin/admin.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { FirstPageComponent } from './first-page/first-page.component';
import { AboutComponent } from './about/about.component';
import { SignupComponent } from './signup/signup.component';
import { ProfileComponent } from './profile/profile.component';

const routes: Routes = [
  {path:'', redirectTo:'first-page',pathMatch:'full'},
  { path: 'user', component: UserComponent },
  { path: 'home', component: HomeComponent },
  { path: 'busbooking', component: BusbookingComponent },
  { path: 'generate-ticket', component: GenerateTicketComponent },
  { path: 'cancel-ticket', component: CancelTicketComponent },
  { path: 'change-password', component: ChangePasswordComponent },
  { path: 'change-age', component: ChangeAgeComponent },
  { path: 'change-name', component: ChangeNameComponent },
  { path: 'change-phone-number', component: ChangePhoneNumberComponent },
  { path: 'feedback-rating', component: FeedbackRatingComponent },
  { path: 'app', component: AppComponent },
  { path: 'admin', component: AdminComponent },
  { path: 'forgot-password', component: ForgotPasswordComponent },
  { path: 'first-page', component: FirstPageComponent },
  { path: 'about', component: AboutComponent },
  { path: 'signup', component: SignupComponent },
  { path: 'profile', component: ProfileComponent },
  { path: 'add-bus-or-route', component: AddBusOrRouteComponent },
  { path: 'generate-report', component: GenerateReportComponent },
  { path: 'cancel-booking', component: CancelBookingComponent },
  { path: 'update-bus-type', component: UpdateBusTypeComponent },
  { path: 'update-boarding-time', component: UpdateBoardingTimeComponent },
  { path: 'update-source-station', component: UpdateSourceStationComponent },
  { path: 'update-destination-station', component: UpdateDestinationStationComponent },
  { path: 'update-drop-time', component: UpdateDropTimeComponent },
  { path: 'update-seats', component: UpdateSeatsComponent },
  { path: 'update-fare', component: UpdateFareComponent },
  { path: 'update-details', component: UpdateDetailsComponent },
  { path: 'admin/adminfunction', component: AdminfunctionComponent }
]
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
