import { Component, OnInit } from '@angular/core';
import { Bus } from 'src/app/Bus';
import { Router } from '@angular/router';
import{BusService} from 'src/app/bus.service';
import { FormGroup,FormControl } from '@angular/forms';

@Component({
  selector: 'app-update-fare',
  templateUrl: './update-fare.component.html',
  styleUrls: ['./update-fare.component.css']
})
export class UpdateFareComponent implements OnInit {
  flag1:boolean;
  tempBus:Bus;

  constructor(private busSer:BusService,router:Router) { }
  updateBusFare=new FormGroup({
    busId:new FormControl,
    fare:new FormControl

  })
  
  ngOnInit(): void {
    this.busSer.getBus();
  }
  updateFare(){
    let busId=this.updateBusFare.get('busId').value;
    let fare=this.updateBusFare.get('fare').value;
    for(let i=0;i<this.busSer.busDb.length;i++)
    {
        if(this.busSer.busDb[i].id==busId)
        {
          this.busSer.busDb[i].fare=fare;
          this.tempBus=this.busSer.busDb[i];
          this.busSer.updateBus(this.busSer.busDb[i].id,this.tempBus).subscribe(data=>(console.log(data)));
          this.flag1=true;

        }
    }

  }

}
