import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Booking } from './Booking';

@Injectable({
  providedIn: 'root'
})
export class BookingService
{
  localurl='./assets/busbooking.json';
  public tempBooking:Booking;
  public flag:boolean=false;
  public bookingDb:any[]=[];
  constructor(private http:HttpClient) { }
  httpOptions={
    headers:new HttpHeaders({
      'Content-Type':'application/json'
    })
}
  getBooking()
  {
   this.http.get<Booking[]>('http://localhost:3000/Booking').subscribe(resp=>{
    for(const bk of(resp as any)){
      this.bookingDb.push({
        id:bk.id,
        busId:bk.busId,
        passengerNames:bk.passengerNames,
        seatBooked:bk.seatBooked,
        passengerEmail:bk.passengerEmail,
        totalFare:bk.totalFare,
    feedBack:bk.feedBack,
    rating:bk.rating,
      })
    }
   console.log(this.bookingDb);
   
   
  });
  }
  addBooking(Booking:Booking)
  {
    return this.http.post('http://localhost:3000/Booking',Booking);
  }

  deleteBooking(id:any)
  {
    console.log("yup......")
    return this.http.delete('http://localhost:3000/Booking/'+id);
  }
 
  updateBooking(id:any,Booking:Booking)
  {
    return this.http.put('http://localhost:3000/Booking/'+id,Booking);
  }
    
}