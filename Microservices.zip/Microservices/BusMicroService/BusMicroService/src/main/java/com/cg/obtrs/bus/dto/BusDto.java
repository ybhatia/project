package com.cg.obtrs.bus.dto;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class BusDto {

	private Integer busId;
	private String sourceStation;
	private String destinationStation;
	private LocalDateTime boardingTime;
	private LocalDateTime dropTime;
	private String busType;
	private Integer totalSeats;
	private Float fare;
	private Integer seatsBooked;

	public BusDto(Integer busId, String sourceStation, String destinationStation, LocalDateTime boardingTime,
			LocalDateTime dropTime, String busType, Integer totalSeats, Float fare, int seatsBooked) {
		super();
		this.busId = busId;
		this.sourceStation = sourceStation;
		this.destinationStation = destinationStation;
		this.busType = busType;
		this.fare = fare;
		this.totalSeats = totalSeats;
		this.boardingTime = boardingTime;
		this.dropTime = dropTime;
		this.seatsBooked = seatsBooked;
	}

	public BusDto() {
		super();
	}

	public int getSeatsBooked() {
		return seatsBooked;
	}

	public void setSeatsBooked(int seatsBooked) {
		this.seatsBooked = seatsBooked;
	}

	public String getSourceStation() {
		return sourceStation;
	}

	public void setSourceStation(String sourceStation) {
		this.sourceStation = sourceStation;
	}

	public String getDestinationStation() {
		return destinationStation;
	}

	public void setDestinationStation(String destinationStation) {
		this.destinationStation = destinationStation;
	}

	public String getBusType() {
		return busType;
	}

	public void setBusType(String busType) {
		this.busType = busType;
	}

	public Integer getTotalSeats() {
		return totalSeats;
	}

	public void setTotalSeats(Integer totalSeats) {
		this.totalSeats = totalSeats;
	}

	public Float getFare() {
		return fare;
	}

	public void setFare(Float fare) {
		this.fare = fare;
	}

	public LocalDateTime getBoardingTime() {
		return boardingTime;
	}

	public void setBoardingTime(LocalDateTime boardingTime) {
		this.boardingTime = boardingTime;
	}

	public LocalDateTime getDropTime() {
		return dropTime;
	}

	public void setDropTime(LocalDateTime dropTime) {
		this.dropTime = dropTime;
	}

	public Integer getBusId() {
		return busId;
	}

	public void setBusId(Integer busId) {
		this.busId = busId;
	}

	@Override
	public String toString() {
		DateTimeFormatter format1 = DateTimeFormatter.ofPattern("dd/MM/yyyy hh:mm a");
		return "\n\t\tBus Id:" + busId + "\n" + "\n\t\tSource Station:" + sourceStation + "\n"
				+ "\n\t\tDestination Station:" + destinationStation + "\n" + "\n\t\tBoarding Time:"
				+ boardingTime.format(format1) + "\n" + "\n\t\tDropTime:" + dropTime.format(format1) + "\n"
				+ "\n\t\tBus Type:" + busType + "\n" + "\n\t\tTotal Seats:" + totalSeats + "\n" + "\n\n";
	}

}
