package com.cg.obtrs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BusMicroServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
