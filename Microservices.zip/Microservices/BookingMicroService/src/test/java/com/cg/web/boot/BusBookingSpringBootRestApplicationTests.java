package com.cg.web.boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BusBookingSpringBootRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
