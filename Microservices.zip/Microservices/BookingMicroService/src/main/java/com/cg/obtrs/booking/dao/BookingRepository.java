package com.cg.obtrs.booking.dao;

import java.math.BigInteger;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
//import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.cg.obtrs.booking.entities.BookingEntity;



@CrossOrigin("http://localhost:4200")
public interface BookingRepository extends JpaRepository<BookingEntity, BigInteger> {
	
	@Query(value = "Select * from Booking where bus_Id = ?", nativeQuery = true)
	List<BookingEntity> getBookingByBusId(BigInteger busId);

}
