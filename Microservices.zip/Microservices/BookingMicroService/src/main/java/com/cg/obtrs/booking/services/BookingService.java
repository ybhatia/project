package com.cg.obtrs.booking.services;

import java.math.BigInteger;
import java.util.List;

import com.cg.obtrs.booking.entities.BookingEntity;
import com.cg.obtrs.booking.exception.CustomException;

public interface BookingService 
{
	 List<BookingEntity> getAllBooking() throws CustomException;
	
	 BookingEntity getBookingById(BigInteger bookingId) throws CustomException;
	
	 BookingEntity addBooking(BookingEntity entity) throws CustomException;
	
	 boolean cancelBooking( BigInteger bookingId) throws CustomException;

	List<BookingEntity> getBookingByBusId(BigInteger busId) throws CustomException;
}
