package com.cg.obtrs.controller;

import java.math.BigInteger;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.obtrs.entities.BusEntity;
import com.cg.obtrs.service.AdminService;

import com.cg.obtrs.entities.BookingEntity;

@RestController
@RequestMapping("/admin")
@CrossOrigin("*")
public class AdminController {
	
	final static Logger logger = Logger.getLogger(AdminController.class);
	
	@Autowired
	AdminService adminService;
	
	@GetMapping("/bus/{busId}")
	public ResponseEntity<BusEntity> getBusByBusId(@PathVariable Integer busId) {
		logger.info(adminService.getBusByBusId(busId));
		return adminService.getBusByBusId(busId);
	}
	
	@GetMapping("/buses")
	public ResponseEntity<List<BusEntity>> getAllBus() {
		logger.info(adminService.getAllBus());
		return adminService.getAllBus();
	}

	@GetMapping("/booking/bus/{busId}")
	public ResponseEntity<List<BookingEntity>> getBookingbyBusId(@PathVariable Integer busId) {
		logger.info(adminService.getBookingbyBusId(busId));
		return adminService.getBookingbyBusId(busId);
	}
	
	@CrossOrigin("*")
	@PostMapping("/addBus")
	public ResponseEntity<BusEntity> addNewBus(@RequestBody BusEntity bus) {
		return adminService.addBus(bus);
	}
	

	@DeleteMapping("/delete/{bookingId}")
	public boolean cancelBooking(@PathVariable BigInteger bookingId) {
		logger.info("BOOKING REMOVED WITH THE BOOKING ID = " + bookingId);
		return adminService.cancelBooking(bookingId);
	

		
	}
}
