package com.cg.obtrs.dao;

import java.math.BigInteger;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.cg.obtrs.entities.BookingEntity;

@CrossOrigin("*")
public interface BookingDao extends JpaRepository<BookingEntity, BigInteger> {

}
