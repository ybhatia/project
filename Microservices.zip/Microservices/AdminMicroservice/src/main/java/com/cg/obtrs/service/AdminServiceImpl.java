package com.cg.obtrs.service;

import java.math.BigInteger;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cg.obtrs.dao.BusDao;
import com.cg.obtrs.entities.BookingEntity;
import com.cg.obtrs.entities.BusEntity;
import com.cg.obtrs.exception.CustomException;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
public class AdminServiceImpl implements AdminService {

	final static Logger logger = Logger.getLogger(AdminServiceImpl.class);

	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private BusDao busDao;

	@Override
	@HystrixCommand(fallbackMethod = "busByBusIdFallbackMethod")
	public ResponseEntity<BusEntity> getBusByBusId(Integer busId) {

		BusEntity bus = restTemplate.getForObject("http://localhost:8082/bus/busbyid/" + busId, BusEntity.class);
		ResponseEntity<BusEntity> response = new ResponseEntity<>(bus, HttpStatus.OK);
		logger.info(response);
		return response;
	}

	@Override
	// @HystrixCommand(fallbackMethod = "bookingByBusIdFallbackMethod")
	public ResponseEntity<List<BookingEntity>> getBookingbyBusId(Integer busId) {
		List<BookingEntity> bookingList = restTemplate
				.getForObject("http://localhost:8081/booking/bookingbyBusId/" + busId, List.class);
		ResponseEntity<List<BookingEntity>> response = new ResponseEntity<>(bookingList, HttpStatus.OK);
		return response;

	}

	@Override
	public ResponseEntity<List<BusEntity>> getAllBus() {
		List<BusEntity> busList = restTemplate.getForObject("http://localhost:8082/bus/buses", List.class);
		ResponseEntity<List<BusEntity>> response = new ResponseEntity<>(busList, HttpStatus.OK);
		return response;
	}

	public ResponseEntity<BusEntity> busByBusIdFallbackMethod(Integer busId) {
		BusEntity bus = new BusEntity(0, "", "", "", "", "", 0, 0.0f, 0);
		ResponseEntity<BusEntity> response = new ResponseEntity<>(bus, HttpStatus.INTERNAL_SERVER_ERROR);
		return response;

	}

	@Override
	public ResponseEntity<BusEntity> addBus(BusEntity bus) {
		HttpEntity<BusEntity> requestEntity = new HttpEntity<BusEntity>(bus);
		ResponseEntity<BusEntity> response = restTemplate.exchange("http://localhost:8082/bus/new", HttpMethod.POST,
				requestEntity, BusEntity.class);
		return response;
	}

	@Override
	public boolean cancelBooking(BigInteger bookingId) {
		restTemplate.delete("http://localhost:8081/booking/delete/" + bookingId);
		return true;

	}

}
