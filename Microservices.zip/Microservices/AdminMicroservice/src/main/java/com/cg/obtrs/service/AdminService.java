package com.cg.obtrs.service;

import java.math.BigInteger;
import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.cg.obtrs.entities.BookingEntity;
import com.cg.obtrs.entities.BusEntity;
import com.cg.obtrs.exception.CustomException;

@Service
public interface AdminService {

	ResponseEntity<BusEntity> getBusByBusId(Integer busId);

	ResponseEntity<List<BookingEntity>> getBookingbyBusId(Integer busId);

	ResponseEntity<List<BusEntity>> getAllBus();

	ResponseEntity<BusEntity> addBus(BusEntity bus) throws CustomException;

	boolean cancelBooking(BigInteger bookingId) throws CustomException;

	//String addBusOrRoute(BusEntity bus);


}
